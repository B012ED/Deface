# B012ED deface

what is B012ED deface tools?<br>
B012ED deface is a tool for defacing dozens or hundreds of sites at once,depending on the number
of sites that have been determined by you, this is not dangerous, and this is only the file upload method<br>

**how to install and usage:**

**Termux:**
* `pkg install python2`
* `pip2 install requests`
* `pkg install git`
* `git clone https://github.com/B012ED/deface`
* `unzip deface`
* `cd deface`
* `python2 def.py`

**Linux:**
* `apt-get install python`
* `apt-get install pthon-pip`
* `pip install requests`
* `apt-get install git`
* `git clone https://github.com/B012ED/deface`
* `unzip deface`
* `cd deface`
* `python def.py`

**NOTE:** before using this tool, put your deface script with the def.py file, edit the file 'target.txt' and enter the target url


